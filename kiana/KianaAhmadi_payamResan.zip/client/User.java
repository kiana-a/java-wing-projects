/**
 * Created by kiana on 12/7/17.
 */
public class User {
    private String name;

    public User(String s) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User() {
        this.name = name;
    }
}
