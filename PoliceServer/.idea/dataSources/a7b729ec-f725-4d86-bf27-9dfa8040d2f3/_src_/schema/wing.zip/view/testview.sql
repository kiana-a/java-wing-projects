CREATE VIEW testview AS
  SELECT `wing`.`book`.`name` AS `name`
  FROM `wing`.`book`
  WHERE (`wing`.`book`.`name` = 'discrete math');
