package run.wing.bookstore.model;

/**
 * Created by kiana on 10/12/17.
 */
public enum Print {
    EXPENSIVE,
    CHEAP,
    SUBJECTS;
}
