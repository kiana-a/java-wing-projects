package run.wing.bookstore.controller;

import run.wing.bookstore.model.Book;
import run.wing.bookstore.model.Print;
import run.wing.bookstore.view.BookView;

import java.util.*;

/**
 * Created by kiana on 10/12/17.
 */
public class BookStore {

    private List<Book> books = new ArrayList<>();
    private BookView bookView = new BookView();

    private static BookStore ourInstance = new BookStore();

    public static BookStore getInstance() {
        return ourInstance;
    }

    private BookStore() {
    }

    public void deleteBook(String isbn) {
        for (Book book : books){
            if (book.getIsbn().equals(isbn)){
                books.remove(book);
                break;
            }
        }
    }
    public void addBook(Book book){
        books.add(book);
    }
    public List<Book> getTop10ExpensiveBooks (){

        List<Book> response = new ArrayList<>();

        TreeMap<Long, Book> bookTreeMap = new TreeMap<>();

        for(Book book : books) {
            bookTreeMap.put(book.getCost(), book);
            if (bookTreeMap.size() > 10)
                bookTreeMap.remove(bookTreeMap.firstKey());


        }

        for (Map.Entry<Long, Book> entry : bookTreeMap.entrySet())
            response.add(entry.getValue());


        return response;
    }
    public List<Book> getTop10CheapBooks () {
        books.sort(Comparator.comparing(Book::getCost));

        return books.subList(0,books.size() > 10 ? 10 : books.size());
    }

    public Set<String> getSubjects (){
        Set<String> subjects = new HashSet<>();
        for (Book book : books)
            subjects.add(book.getSubject());
        return subjects;
    }

    public void print(Print p){
        switch (p){
            case CHEAP:
                bookView.printBooks(this.getTop10CheapBooks());
                break;
            case SUBJECTS:
                bookView.printSubjects(this.getSubjects());
                break;
            case EXPENSIVE:
                bookView.printBooks(this.getTop10ExpensiveBooks());
                break;
            default:

        }
    }
}
